<?
?>
<!DOCTYPE html>
<html>
<head>
<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
	.footer{
		position: relative;
		width: 100%;
		height: 40px;
		
		padding-left: 30%;
	}
	/*
	@media screen and (max-width:500px) and (min-width: 0px){
		.footer{
			width: 100%;
			height: auto;
		}	
		.footer p{
			font-size: 15px;
			color: red;
		}
		.footer  p a{
			text-decoration: none;
			font-style: italic;
			padding-left: 20%;
		}
	}
*/
	</style>
</head>
<body>
<div class="footer">
	   	<p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved |  <i class="icon-heart" aria-hidden="true"></i> <a href="https://thedanielolabemiwo.com" target="_blank" id="foota">Daniel Olabemiwo</a>
		</p>
 </div>
</body>
</html>